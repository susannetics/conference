# =====================================
# Sequence
# =====================================

# code executes from top to bottom

a = 1           # executes first
b = 2           # executes second
c = 3           # executes third
d = a + b + c   # executes fourth

print(d)        # executes fifth
