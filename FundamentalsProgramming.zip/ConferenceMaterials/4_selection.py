# =====================================
# Selection
# =====================================

# IF
number = 10

if number % 3 == 0:     # the condition
    print('Fizz')       # the body, notice tab


# IF / ELSE
number = 10

if number % 3 == 0:
    print('Fizz')
else:
    print(number)


# IF / ELIF
number = 10

if number % 3 == 0:
    print('Fizz')
elif number % 5 == 0:
    print('Buzz')



# IF / ELIF / ELSE
number = 10

if number % 3 == 0:      # must be first clause, only one allowed
    print('Fizz')
elif number % 5 == 0:    # can only exist between if and else clause, can have as many as you want
    print('Buzz')
else:               # must be last clause, only one allowed
    print(number)


# Complex Condition
number = 10

if number % 3 == 0 and number % 5 == 0:     # uses the logical AND operator, both conditions must be true
    print('FizzBuzz')
elif number % 3 == 0:
    print('Fizz')
elif number % 5 == 0:
    print('Buzz')
else:
    print(number)
