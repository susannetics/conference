# =====================================
# What Can We Do With Data
# =====================================

# Operators
# -------------------------------------

# assignment
a = 1
b = a  # b is 1

# math
1 + 2  # addition
1 - 2  # subtraction
1 * 2  # multiplication
1 / 2  # division
1 // 2  # integer division
1 % 2  # modular division
1 ** 2  # exponent (1 raised to the power of 2)

x = 5
y = x ** 2  # y is 25

# relational
1 < 2   # less than, evaluates to True
1 > 2   # greater than, evaluates to False
1 <= 2  # less than or equal to, evaluates to True
1 <= 2  # greater than or equal to, evaluates to False
1 == 2  # equal to, evaluates to False
1 != 2  # not equal to, evaluates to True

# logic (and, or, not)
True and True  # is True
True or False  # is True
not True       # is False

a = True
b = False

a and b  # is False

c = a and (b and not b) or b  # c is False
