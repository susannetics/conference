# =====================================
# Repetition
# =====================================

# FOR, when you know how many iterations you want to make
for i in range(10):
    print(i)            # prints 0 through 9

for i in range(5, 10):
    print(i)            # prints 5 through 9

for i in range(10, 1, -1):
    print(i)            # prints 2 through 10, starting from 10 and moving backwards

for i in range(0, 10, 2):
    print(i)            # print 0, 2, 4, 6, 8


# WHILE, when you don't know how many iterations you want to make
i = 0
while i < 10:
    print(i)
    i += 1      # shorthand for i = i + 1, the right side of statement is always evaluated first, before assignment




# Loops with Lists

#          0  1  2  3  4     access values by index, ex: numbers[2] is 3
numbers = [1, 2, 3, 4, 5]  # numbers[2] points to where the value 3 is stored in memory


for number in numbers:   # FOREACH loop
    print(number)        # valid
    print(number * 2)    # valid
    number = number * 2  # valid, but won't actually change the list, must use a FOR loop

print(numbers)

# number in the FOREACH loop represents the literal value from the list and cannot be changed
for number in range(len(numbers)):
    numbers[number] *= 2    # directly accesses where the value is stored in memory
                            # and assigns a new value to live at that memory cell

print(numbers)


# The Exception! When the value is a reference type
numberLists = [[1,2], [3,4]]    # a 2 dimensional list! (a list of lists)
print(numberLists)

for numberList in numberLists:
    numberList.append(1)

print(numberLists)

# nested loops
numberLists = [[1,2], [3,4]]

for numberList in numberLists:
    for number in numberList:
        print(number)

# all together now
for i in range(5):
    for j in range(10):
        if j % 2 == 0:
            print('x', end='')      # end='' stops the cursor from moving to a new line
        else:                       # after printing to the screen
            print('o', end='')

    print()
