# =====================================
# Functions
# =====================================

# Giving a name to a block of code
# Makes code modular
# Stops you from repeating yourself


# defining a function
def sayHello():
    print("Hello!")


# calling a function
sayHello()


# functions with arguments
def sayHelloTo(name):
    print(f'Hello, {name}!')


# calling a function with arguments
sayHelloTo("Athena")


# functions that give back information
def add(a, b):
    return a + b


# calling a function that returns
x = 1
theSum = add(x, 2)
print(theSum)