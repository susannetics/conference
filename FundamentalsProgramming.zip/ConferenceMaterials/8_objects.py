# =====================================
# Objects
# =====================================

class Person:
    def __init__(self, name, age):     # constructor, magic function
        self.name = name               # instance properties
        self.age = age

    def introduce(self):                # member function
        print(f'Hello, my name is {self.name} and I am {self.age} years old.')


jane = Person('Jane', 41)       # calls the __init__ function in the Person class
joe = Person('Joe', 28)         # two separate instances are created from the same blueprint

jane.introduce()                # so, the same function call will behave
joe.introduce()                 # differently depending on which instance called it


# Inheritance
class Student(Person):
    def __init__(self, name, age, id):
        super().__init__(name, age)
        self.id = id                    # a property unique to the Student class, it expands the base class

    def introduce(self):
        super().introduce()             # calls base class introduce function
        print(f'My id is {self.id}')    # expands on the base class function

    def takeClass(self, className):     # a function unique to the Student class, it expands the base class
        print(f'I will take {className} this semester')


student = Student('Plato', 22, '12345')
student.introduce()
student.takeClass('CSC 120')