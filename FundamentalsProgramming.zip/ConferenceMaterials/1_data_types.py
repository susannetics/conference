# =====================================
# Data Types
# =====================================

# Literals
# -------------------------------------

42                      # int

3.14159                 # float

True                    # bool

"Hello, World!"         # string

[1, 2, False]           # list

{                       # dictionary
    'name': 'Jane',
    'age': 32
}


# Variables
# -------------------------------------

number = 42                 # int

pi = 3.14159                # float

iLikePython = True          # bool

greeting = "Hello, World!"  # string

myList = [1, 2, False]      # list

myDictionary = {            # dictionary
    'name': 'Jane',
    'age': 32
}

# GIVE YOUR VARIABLES GOOD NAMES!
# Pick a naming convention and stick to it!

# snake_case    <-- preferred Python convention
# camelCase
# PascalCase